'use strict';

const AWS = require('aws-sdk');
const sharp = require('sharp');

const s3 = new AWS.s3();

exports.resize = async (event, context, callback) => {
    const srcBucket = event.Records[0].s3.bucket.name;
    const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));
    const dstBucket = srcBucket;
    const dstKey = "resized-" + srcKey;

    const dims = srcKey.split("_")[0];
    const dimsArray = dims.split("-");

    var width = '';
    var height = '';

    if (dimsArray.length == 2) {
        width = parseInt(dimsArray[0]);
        height = parseInt(dimsArray[1]);
    } else {
        if (dims.charAt(0) == '-') {
            height = parseInt(dimsArray[0]);
        } else {
            width = parseInt(dimsArray[0]);
        }
    }

    try {
        const params = {
            Bucket: srcBucket,
            Key: srcKey
        };
        var origimage = await s3.getObject(params).promise();
    } catch (error) {
        console.log(error);
        return;
    }

    try {
        if (width == '') {
            var buffer = await sharp(origimage.Body).resize({height: height}).toBuffer();
        } else if (height == '') {
            var buffer = await sharp(origimage.Body).resize({width: width}).toBuffer();
        } else {
            var buffer = await sharp(origimage.Body).resize({width: width, height: height}).toBuffer();
        }
    } catch (error) {
        console.log(error);
        return;
    }

    try {
        const dstParams = {
            Bucket: dstBucket,
            Key: dstKey,
            Body: buffer,
            ContentType: "image"
        };
        const putResult = await s3.putObject(dstParams).promise();
    } catch (error) {
        console.log(error);
        return;
    }
    console.log("SUccessfully resized " + srcBucket + '/' + srcKey +
    ' and uploaded to ' + dstBucket + '/' + dstKey);
};
